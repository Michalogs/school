[![GitPitch](https://gitpitch.com/assets/badge.svg)](https://gitpitch.com/gitpitch/code-presenting)

# Blog Post - Let Your Code Do The Talking

This repository contains the companion presentation for the GitPitch [Let Your Code Do The Talking](https://medium.com/@gitpitch/let-your-code-do-the-talking-983906a3a587) blog post on [Medium](https://medium.com/@gitpitch/let-your-code-do-the-talking-983906a3a587).